<?php
if($_SERVER['HTTP_USER_AGENT'] === "Mickey"){
    echo "<h1>flag{hehe_nice_catch}</h1>}";
    } else {
    echo "<h1>only Mickey can access this site. why are you here?</h1>";
    }
    ?>