<?php
if($_SERVER['HTTP_USER_AGENT'] === "HariBahadur"){
    echo "can you print the fl﻿‌‌​​​‌​⁠‌​‌​‌‌‌⁠‌​​​‌‌​⁠‌‌​‌‌‌‌⁠‌​‌‌​​‌⁠‌​‌​‌‌​⁠‌‌‌​​‌⁠‌‌‌​​​‌⁠‌‌​​​‌​⁠‌‌​​‌​⁠‌​‌​​‌​⁠‌‌‌​​​​﻿ag?";
    } else {
    echo "<h1>आरु हेर्छ कि भनेर लुकको के। यो कुरो त HariBahadur ले मात्र देख छ।  </h1>";
    }
    ?>
   